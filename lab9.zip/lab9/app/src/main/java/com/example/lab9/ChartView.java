package com.example.lab9;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class ChartView extends View {

    private Paint axisPaint;   // vẽ trục
    private Paint barPaint;    // vẽ cột
    private Paint textPaint;   // vẽ chữ

    private float[] values = {30, 60, 90};
    private String[] labels = {"A", "B", "C"};
    private float maxValue = 100f;

    public ChartView(Context context) {
        super(context);
        init();
    }

    public ChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        axisPaint = new Paint();
        axisPaint.setColor(Color.BLACK);
        axisPaint.setStrokeWidth(5f);
        axisPaint.setStyle(Paint.Style.STROKE);

        barPaint = new Paint();
        barPaint.setColor(Color.BLUE);
        barPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(40f);
        textPaint.setAntiAlias(true);
    }

    public void setData(float[] values, String[] labels) {
        if (values == null || values.length == 0) return;
        this.values = values;

        if (labels != null && labels.length == values.length) {
            this.labels = labels;
        }

        // Tìm max để scale chiều cao cột
        maxValue = values[0];
        for (float v : values) {
            if (v > maxValue) maxValue = v;
        }

        invalidate(); // vẽ lại
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(Color.WHITE);

        int w = getWidth();
        int h = getHeight();

        int paddingLeft = 100;
        int paddingBottom = 100;
        int paddingTop = 50;
        int paddingRight = 50;

        int chartWidth = w - paddingLeft - paddingRight;
        int chartHeight = h - paddingTop - paddingBottom;

        // Vẽ trục X, Y
        canvas.drawLine(paddingLeft, paddingTop,
                paddingLeft, paddingTop + chartHeight, axisPaint); // trục Y
        canvas.drawLine(paddingLeft, paddingTop + chartHeight,
                paddingLeft + chartWidth, paddingTop + chartHeight, axisPaint); // trục X

        if (values == null || values.length == 0) return;

        int n = values.length;
        float barSpace = chartWidth / (n * 2f);
        float barWidth = barSpace;
        float startX = paddingLeft + barSpace / 2f;

        for (int i = 0; i < n; i++) {
            float value = values[i];
            float ratio = value / maxValue; // tỉ lệ so với max
            float barHeight = chartHeight * ratio;

            float left = startX + i * barSpace * 2;
            float top = paddingTop + chartHeight - barHeight;
            float right = left + barWidth;
            float bottom = paddingTop + chartHeight;

            // Vẽ cột
            canvas.drawRect(left, top, right, bottom, barPaint);

            // Vẽ nhãn dưới cột
            String label = (labels != null && i < labels.length) ? labels[i] : String.valueOf(i + 1);
            float textWidth = textPaint.measureText(label);
            canvas.drawText(label,
                    left + (barWidth - textWidth) / 2,
                    bottom + 40,
                    textPaint);
        }
    }
}
