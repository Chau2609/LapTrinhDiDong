package com.example.lab9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Random;

public class RaceActivity extends AppCompatActivity {

    private ProgressBar pbRunner1, pbRunner2, pbRunner3;
    private Button btnStartRace;

    // 2 cờ trạng thái dùng cho nhiều thread
    private volatile boolean isRunning = false; // đang đua không
    private volatile boolean hasWinner = false; // đã có thằng thắng chưa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_race);

        // Ánh xạ view
        pbRunner1 = findViewById(R.id.pbRunner1);
        pbRunner2 = findViewById(R.id.pbRunner2);
        pbRunner3 = findViewById(R.id.pbRunner3);
        btnStartRace = findViewById(R.id.btnStartRace);

        btnStartRace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRace();
            }
        });
    }

    // Hàm bắt đầu cuộc đua
    private void startRace() {
        isRunning = true;
        hasWinner = false;

        // Reset tiến độ
        pbRunner1.setProgress(0);
        pbRunner2.setProgress(0);
        pbRunner3.setProgress(0);

        // Khóa nút để không bấm thêm khi đang đua
        btnStartRace.setEnabled(false);

        // Tạo 3 thread, mỗi thread là 1 vận động viên
        new Thread(new Racer(pbRunner1, "1")).start();
        new Thread(new Racer(pbRunner2, "2")).start();
        new Thread(new Racer(pbRunner3, "3")).start();
    }

    // Lớp Racer mô tả 1 người chơi chạy trên 1 Thread riêng
    private class Racer implements Runnable {

        private ProgressBar progressBar;
        private String name;
        private Random random = new Random();
        private int progress = 0;

        Racer(ProgressBar progressBar, String name) {
            this.progressBar = progressBar;
            this.name = name;
        }

        @Override
        public void run() {
            while (isRunning && progress < 100) {
                try {
                    // nghỉ 100–300ms cho giống đang "chạy"
                    Thread.sleep(100 + random.nextInt(200));
                } catch (InterruptedException e) {
                    return;
                }

                // tăng tiến độ 1–6% mỗi lần
                progress += random.nextInt(6) + 1;
                if (progress > 100) progress = 100;

                // Cập nhật UI phải chạy trên main thread
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setProgress(progress);

                        // Nếu đã tới đích và chưa ai thắng
                        if (progress >= 100 && !hasWinner) {
                            hasWinner = true;
                            isRunning = false;

                            Toast.makeText(RaceActivity.this,
                                    "Người chơi " + name + " thắng!",
                                    Toast.LENGTH_SHORT).show();

                            // mở lại nút để chơi tiếp
                            btnStartRace.setEnabled(true);
                        }
                    }
                });
            }
        }
    }
}
