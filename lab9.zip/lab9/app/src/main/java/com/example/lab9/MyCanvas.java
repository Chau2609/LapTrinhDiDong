package com.example.lab9;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class MyCanvas extends View {

    private Paint axisPaint;   // vẽ trục
    private Paint barPaint;    // vẽ cột
    private Paint textPaint;   // vẽ chữ

    private float[] values = {30, 60, 90};   // dữ liệu mặc định
    private String[] labels = {"A", "B", "C"};
    private float maxValue = 100f;

    private int[] barColors;   // màu của từng cột
    private Random random;

    public MyCanvas(Context context) {
        super(context);
        init();
    }

    public MyCanvas(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        axisPaint = new Paint();
        axisPaint.setColor(Color.BLACK);
        axisPaint.setStrokeWidth(5f);
        axisPaint.setStyle(Paint.Style.STROKE);

        barPaint = new Paint();
        barPaint.setStyle(Paint.Style.FILL);

        textPaint = new Paint();
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(40f);
        textPaint.setAntiAlias(true);

        random = new Random();

        // màu mặc định ban đầu
        barColors = new int[]{Color.RED, Color.GREEN, Color.BLUE};
    }

    // Gọi hàm này khi bấm nút Draw
    public void randomData() {
        // tạo ngẫu nhiên 3 giá trị 10–100
        values = new float[3];
        barColors = new int[3];

        for (int i = 0; i < values.length; i++) {
            values[i] = 10 + random.nextInt(91); // 10..100

            // random màu cho từng cột
            int r = random.nextInt(256);
            int g = random.nextInt(256);
            int b = random.nextInt(256);
            barColors[i] = Color.rgb(r, g, b);
        }

        // tìm max để scale
        maxValue = values[0];
        for (float v : values) {
            if (v > maxValue) maxValue = v;
        }

        invalidate(); // yêu cầu vẽ lại -> gọi onDraw
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(Color.WHITE);

        int w = getWidth();
        int h = getHeight();

        int paddingLeft = 100;
        int paddingBottom = 120;
        int paddingTop = 50;
        int paddingRight = 50;

        int chartWidth = w - paddingLeft - paddingRight;
        int chartHeight = h - paddingTop - paddingBottom;

        // vẽ trục X, Y
        canvas.drawLine(
                paddingLeft,
                paddingTop,
                paddingLeft,
                paddingTop + chartHeight,
                axisPaint
        );

        canvas.drawLine(
                paddingLeft,
                paddingTop + chartHeight,
                paddingLeft + chartWidth,
                paddingTop + chartHeight,
                axisPaint
        );

        if (values == null || values.length == 0) return;

        int n = values.length;
        float barSpace = chartWidth / (n * 2f); // khoảng cách + rộng cột
        float barWidth = barSpace;
        float startX = paddingLeft + barSpace / 2f;

        for (int i = 0; i < n; i++) {
            float value = values[i];
            float ratio = value / maxValue; // tỉ lệ chiều cao
            float barHeight = chartHeight * ratio;

            float left = startX + i * barSpace * 2;
            float top = paddingTop + chartHeight - barHeight;
            float right = left + barWidth;
            float bottom = paddingTop + chartHeight;

            // set màu riêng cho từng cột
            if (barColors != null && i < barColors.length) {
                barPaint.setColor(barColors[i]);
            } else {
                barPaint.setColor(Color.BLUE);
            }

            // vẽ cột
            canvas.drawRect(left, top, right, bottom, barPaint);

            // vẽ label (A, B, C) dưới cột
            String label = (labels != null && i < labels.length) ? labels[i] : String.valueOf(i + 1);
            float textWidth = textPaint.measureText(label);
            canvas.drawText(label,
                    left + (barWidth - textWidth) / 2,
                    bottom + 40,
                    textPaint);

            // vẽ giá trị trên đầu cột (vd: 75)
            String valueText = String.valueOf((int) value);
            float valueWidth = textPaint.measureText(valueText);
            canvas.drawText(valueText,
                    left + (barWidth - valueWidth) / 2,
                    top - 10,
                    textPaint);
        }
    }
}
