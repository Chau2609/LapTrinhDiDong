package com.example.lab9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private MyCanvas myCanvas;
    private Button btnDraw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myCanvas = findViewById(R.id.myCanvas);
        btnDraw = findViewById(R.id.btnDraw);

        // Lần đầu mở app: có thể tự vẽ dữ liệu mặc định
        myCanvas.randomData();

        btnDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mỗi lần bấm: tạo dữ liệu mới + vẽ lại biểu đồ
                myCanvas.randomData();
            }
        });
    }
}
