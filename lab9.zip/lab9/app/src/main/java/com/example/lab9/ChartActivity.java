package com.example.lab9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ChartActivity extends AppCompatActivity {

    private ChartView chartView;
    private EditText edtValue1, edtValue2, edtValue3;
    private Button btnDrawChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        chartView = findViewById(R.id.chartView);
        edtValue1 = findViewById(R.id.edtValue1);
        edtValue2 = findViewById(R.id.edtValue2);
        edtValue3 = findViewById(R.id.edtValue3);
        btnDrawChart = findViewById(R.id.btnDrawChart);

        btnDrawChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float v1 = parseFloat(edtValue1.getText().toString(), 30);
                float v2 = parseFloat(edtValue2.getText().toString(), 60);
                float v3 = parseFloat(edtValue3.getText().toString(), 90);

                float[] values = {v1, v2, v3};
                String[] labels = {"A", "B", "C"};

                chartView.setData(values, labels);
            }
        });
    }

    private float parseFloat(String text, float defaultValue) {
        try {
            return Float.parseFloat(text);
        } catch (Exception e) {
            return defaultValue;
        }
    }
}
