package com.example.lab3;   // sửa cho đúng package của project

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // ======== PHẦN ĐỔI TIỀN ========

    private final String[] currencyNames = {
            "American Dollar (USD)",        // 0
            "European Cash (EUR)",          // 1
            "Great Britain Pound (GBP)",    // 2
            "Australia Dollar (AUD)",       // 3
            "Canadian Dollar (CAD)",        // 4
            "South Africa Rand (ZAR)",      // 5
            "New Zealand Dollar (NZD)",     // 6
            "Indian Rupee (INR)",           // 7
            "Yên Nhật (JPY)",               // 8
            "Việt Nam Đồng (VND)"           // 9
    };

    private final String[] currencyUnits = {
            "USD", "EUR", "GBP", "AUD", "CAD",
            "ZAR", "NZD", "INR", "JPY", "VNĐ"
    };

    // 1 đơn vị = bao nhiêu VND (số demo)
    private final double[] exchangeRatesToVND = {
            24000,   // USD
            26000,   // EUR
            30000,   // GBP
            16000,   // AUD
            18000,   // CAD
            1300,    // ZAR
            15000,   // NZD
            300,     // INR
            200,     // JPY
            1        // VND
    };

    private EditText edtAmount;
    private Spinner spinnerFrom, spinnerTo;
    private Button btnConvert;
    private TextView tvResult;

    // ======== PHẦN ĐỔI ĐỘ DÀI ========

    // 0=Hải lý, 1=Dặm, 2=Km, 3=Lý, 4=Met, 5=Yard, 6=Foot, 7=Inch
    private final String[] unitNames = {
            "Hải lý",
            "Dặm",
            "Kilometer",
            "Lý",
            "Met",
            "Yard",
            "Foot",
            "Inch"
    };

    // lengthRates[from][to] = 1 from = ? to
    private final double[][] lengthRates = {
            //          Hải lý       Dặm          Km           Lý          Met        Yard        Foot        Inch
            {1.00000000, 1.15077945, 1.85200000, 20.25371830, 1852.0000, 2025.37183, 6076.11549, 72913.38583}, // Hải lý
            {0.86897624, 1.00000000, 1.60934400, 17.60000000, 1609.3440, 1760.00000, 5280.00000, 63360.00000}, // Dặm
            {0.53995680, 0.62137119, 1.00000000, 10.93613300, 1000.0000, 1093.61330, 3280.83990, 39370.07874}, // Km
            {0.04937365, 0.05681818, 0.09144000, 1.00000000,   91.4400,  100.00000,  300.00000,  3600.00000}, // Lý
            {0.00053996, 0.00062137, 0.00100000, 0.01093610,    1.0000,    1.09361,    3.28084,    39.37008}, // Met
            {0.00049374, 0.00056818, 0.00091440, 0.01000000,    0.9144,    1.00000,    3.00000,    36.00000}, // Yard
            {0.00016458, 0.00018939, 0.00030480, 0.00333330,    0.3048,    0.33333,    1.00000,    12.00000}, // Foot
            {0.00001371, 0.00001578, 0.00002540, 0.00027780,    0.0254,    0.02778,    0.08333,     1.00000}  // Inch
    };

    private EditText edtLengthValue;
    private Spinner spinnerFromUnit;
    private ListView lvLengthResults;

    private ArrayAdapter<String> lengthListAdapter;
    private final ArrayList<String> lengthData = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ===== ĐỔI TIỀN =====
        edtAmount   = findViewById(R.id.edtAmount);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo   = findViewById(R.id.spinnerTo);
        btnConvert  = findViewById(R.id.btnConvert);
        tvResult    = findViewById(R.id.tvResult);

        ArrayAdapter<String> currencyAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                currencyNames
        );
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(currencyAdapter);
        spinnerTo.setAdapter(currencyAdapter);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertMoney();
            }
        });

        // ===== ĐỔI ĐỘ DÀI =====
        edtLengthValue  = findViewById(R.id.edtLengthValue);
        spinnerFromUnit = findViewById(R.id.spinnerFromUnit);
        lvLengthResults = findViewById(R.id.lvLengthResults);

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                unitNames
        );
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromUnit.setAdapter(unitAdapter);

        // Header "Tương đương với" nền vàng giống ảnh lab
        TextView header = new TextView(this);
        header.setText("Tương đương với");
        header.setTextSize(16f);
        header.setTextColor(Color.BLACK);
        header.setBackgroundColor(Color.parseColor("#FFCC00"));
        header.setPadding(16, 12, 16, 12);
        lvLengthResults.addHeaderView(header, null, false);

        // Adapter danh sách kết quả
        lengthListAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                lengthData
        );
        lvLengthResults.setAdapter(lengthListAdapter);

        // Khi đổi đơn vị
        spinnerFromUnit.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                updateLengthResults();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });

        // Khi nhập số mới
        edtLengthValue.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                updateLengthResults();
            }
        });
    }

    // ===== HÀM ĐỔI TIỀN =====
    private void convertMoney() {
        String input = edtAmount.getText().toString().trim();

        if (input.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập số tiền", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Số tiền không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        int fromIndex = spinnerFrom.getSelectedItemPosition();
        int toIndex   = spinnerTo.getSelectedItemPosition();

        double inVnd  = amount * exchangeRatesToVND[fromIndex];
        double result = inVnd / exchangeRatesToVND[toIndex];

        String unitTo = currencyUnits[toIndex];
        String display = "Kết quả: " + String.format(Locale.US, "%.4f", result) + " " + unitTo;
        tvResult.setText(display);
    }

    // ===== HÀM CẬP NHẬT KẾT QUẢ ĐỘ DÀI =====
    private void updateLengthResults() {
        lengthData.clear();

        String input = edtLengthValue.getText().toString().trim();
        if (input.isEmpty()) {
            lengthListAdapter.notifyDataSetChanged();
            return;
        }

        double value;
        try {
            value = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Giá trị không hợp lệ", Toast.LENGTH_SHORT).show();
            lengthListAdapter.notifyDataSetChanged();
            return;
        }

        int fromIndex = spinnerFromUnit.getSelectedItemPosition();

        for (int toIndex = 0; toIndex < unitNames.length; toIndex++) {
            double result = value * lengthRates[fromIndex][toIndex];
            String line = String.format(Locale.US, "%.4f   %s", result, unitNames[toIndex]);
            lengthData.add(line);
        }

        lengthListAdapter.notifyDataSetChanged();
    }
}
