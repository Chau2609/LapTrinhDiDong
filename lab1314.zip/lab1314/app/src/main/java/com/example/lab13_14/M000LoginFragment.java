package com.example.lab13_14;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class M000LoginFragment extends Fragment implements View.OnClickListener {
    private EditText edtEmail, edtPass;
    private Context mContext;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context; // Lưu context để sử dụng sau này
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Gắn layout XML vào Fragment
        View rootView = inflater.inflate(R.layout.m000_frg_login, container, false);
        initView(rootView);
        return rootView;
    }

    // Khởi tạo các view và sự kiện click
    private void initView(View v) {
        edtEmail = v.findViewById(R.id.edt_email);
        edtPass = v.findViewById(R.id.edt_pass);

        // Gán sự kiện click cho nút Login và nút chuyển sang Register
        v.findViewById(R.id.tv_login).setOnClickListener(this);
        v.findViewById(R.id.tv_register).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Hiệu ứng mờ dần khi click
        v.startAnimation(AnimationUtils.loadAnimation(mContext, androidx.appcompat.R.anim.abc_fade_in));

        if (v.getId() == R.id.tv_login) {
            // Xử lý khi ấn nút Login
            login(edtEmail.getText().toString(), edtPass.getText().toString());
        } else if (v.getId() == R.id.tv_register) {
            // Chuyển sang màn hình đăng ký
            ((MainActivity) mContext).gotoRegisterScreen();
        }
    }

    private void login(String mail, String pass) {
        // 1. Kiểm tra rỗng
        if (mail.isEmpty() || pass.isEmpty()) {
            Toast.makeText(mContext, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Lấy dữ liệu từ SharedPreferences (nơi lưu trữ tài khoản)
        SharedPreferences pref = mContext.getSharedPreferences(MainActivity.SAVE_PREF, Context.MODE_PRIVATE);
        String savedPass = pref.getString(mail, null); // Tìm pass theo key là email

        // 3. Kiểm tra logic đăng nhập
        if (savedPass == null) {
            Toast.makeText(mContext, "Email không tồn tại!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!pass.equals(savedPass)) {
            Toast.makeText(mContext, "Mật khẩu không đúng!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 4. Đăng nhập thành công
        Toast.makeText(mContext, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
    }
}