package com.example.lab13_14;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class M001RegisterFragment extends Fragment implements View.OnClickListener {
    private EditText edtEmail, edtPass, edtRepass;
    private Context mContext;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m001_frg_register, container, false);
        initView(rootView);
        return rootView;
    }

    private void initView(View v) {
        edtEmail = v.findViewById(R.id.edt_email);
        edtPass = v.findViewById(R.id.edt_pass);
        edtRepass = v.findViewById(R.id.edt_re_pass);

        // Sự kiện click nút Đăng ký và nút Back
        v.findViewById(R.id.tv_register).setOnClickListener(this);
        v.findViewById(R.id.iv_back).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(mContext, androidx.appcompat.R.anim.abc_fade_in));

        if (v.getId() == R.id.iv_back) {
            // Quay lại màn hình đăng nhập
            ((MainActivity) mContext).gotoLoginScreen();
        } else if (v.getId() == R.id.tv_register) {
            // Xử lý đăng ký
            register(edtEmail.getText().toString(), edtPass.getText().toString(), edtRepass.getText().toString());
        }
    }

    private void register(String mail, String pass, String repass) {
        // 1. Kiểm tra dữ liệu đầu vào
        if (mail.isEmpty() || pass.isEmpty() || repass.isEmpty()) {
            Toast.makeText(mContext, "Không được để trống!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!pass.equals(repass)) {
            Toast.makeText(mContext, "Mật khẩu nhập lại không khớp!", Toast.LENGTH_SHORT).show();
            return; // Dừng lại nếu mật khẩu không khớp
        }

        // 2. Kiểm tra xem email đã tồn tại chưa
        SharedPreferences pref = mContext.getSharedPreferences(MainActivity.SAVE_PREF, Context.MODE_PRIVATE);
        String savedPass = pref.getString(mail, null);

        if (savedPass != null) {
            Toast.makeText(mContext, "Email này đã được đăng ký!", Toast.LENGTH_SHORT).show();
            return;
        }

        // 3. Lưu tài khoản mới vào SharedPreferences
        // Key là email, Value là password
        pref.edit().putString(mail, pass).apply();

        Toast.makeText(mContext, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();

        // 4. Tự động chuyển về màn hình đăng nhập
        ((MainActivity) mContext).gotoLoginScreen();
    }
}