package com.example.lab1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    // Bài 1: Máy tính
    private lateinit var edtA: EditText
    private lateinit var edtB: EditText
    private lateinit var txtResult: TextView
    private lateinit var btnAdd: Button
    private lateinit var btnSub: Button
    private lateinit var btnMul: Button
    private lateinit var btnDiv: Button
    private lateinit var btnMod: Button

    // Camera
    private lateinit var btnCamera: Button
    private lateinit var imgPhoto: ImageView
    private lateinit var cameraLauncher: ActivityResultLauncher<Intent>

    // Bài 2: Xúc xắc
    private lateinit var btnRandom: Button
    private lateinit var txtRandom: TextView
    private lateinit var imgDice: ImageView

    // Bài 3: Gọi điện & SMS
    private lateinit var edtPhone: EditText
    private lateinit var btnCall: Button
    private lateinit var btnSMS: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initControls()
        setupCameraLauncher()
        requestCameraPermission()
        initEvents()
    }

    private fun initControls() {
        // Bài 1
        edtA = findViewById(R.id.edtA)
        edtB = findViewById(R.id.edtB)
        txtResult = findViewById(R.id.txtResult)
        btnAdd = findViewById(R.id.btnAdd)
        btnSub = findViewById(R.id.btnSub)
        btnMul = findViewById(R.id.btnMul)
        btnDiv = findViewById(R.id.btnDiv)
        btnMod = findViewById(R.id.btnMod)

        // Camera
        btnCamera = findViewById(R.id.btnCamera)
        imgPhoto = findViewById(R.id.imgPhoto)

        // Bài 2
        btnRandom = findViewById(R.id.btnRandom)
        txtRandom = findViewById(R.id.txtRandom)
        imgDice = findViewById(R.id.imgDice)

        // Bài 3
        edtPhone = findViewById(R.id.edtPhone)
        btnCall = findViewById(R.id.btnCall)
        btnSMS = findViewById(R.id.btnSMS)
    }

    // 📸 Cấu hình Camera theo kiểu mới
    private fun setupCameraLauncher() {
        cameraLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val extras = result.data!!.extras
                val imageBitmap = extras?.get("data") as? Bitmap
                imgPhoto.setImageBitmap(imageBitmap)
            }
        }
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
        }
    }

    private fun initEvents() {
        // 🔢 Bài 1: Máy tính
        btnAdd.setOnClickListener { calculate('+') }
        btnSub.setOnClickListener { calculate('-') }
        btnMul.setOnClickListener { calculate('*') }
        btnDiv.setOnClickListener { calculate('/') }
        btnMod.setOnClickListener { calculate('%') }

        // 📸 Camera
        btnCamera.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraLauncher.launch(intent)
        }

        // 🎲 Bài 2: Xúc xắc ngẫu nhiên
        btnRandom.setOnClickListener {
            val rd = Random()
            val num = rd.nextInt(6) + 1
            txtRandom.text = "Kết quả ngẫu nhiên: $num"
            val diceRes = when (num) {
                1 -> R.drawable.dice1
                2 -> R.drawable.dice2
                3 -> R.drawable.dice3
                4 -> R.drawable.dice4
                5 -> R.drawable.dice5
                else -> R.drawable.dice6
            }
            imgDice.setImageResource(diceRes)
        }

        // 📞 Gọi điện
        btnCall.setOnClickListener {
            val phone = edtPhone.text.toString()
            if (phone.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:$phone")
                startActivity(intent)
            } else {
                Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show()
            }
        }

        // 💬 Nhắn tin
        btnSMS.setOnClickListener {
            val phone = edtPhone.text.toString()
            if (phone.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse("sms:$phone")
                intent.putExtra("sms_body", "Xin chào, đây là tin nhắn mẫu!")
                startActivity(intent)
            } else {
                Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 🧮 Hàm tính toán
    private fun calculate(op: Char) {
        val a = edtA.text.toString().toDoubleOrNull()
        val b = edtB.text.toString().toDoubleOrNull()
        if (a == null || b == null) {
            txtResult.text = "Nhập giá trị hợp lệ!"
            return
        }

        val result = when (op) {
            '+' -> a + b
            '-' -> a - b
            '*' -> a * b
            '/' -> if (b != 0.0) a / b else Double.NaN
            '%' -> a % b
            else -> 0.0
        }
        txtResult.text = "Kết quả: $result"
    }
}
